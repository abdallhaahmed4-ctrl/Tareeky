import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const TareeqyNativeApp());
}

class AppConstants {
  static const appName = 'Tareeqy Native';
  static const appVersion = '1.0.0-native-mvp';
  static const backupVersion = 1;
  static const defaultPin = '135790';
}

class Storage {
  static SharedPreferences? _prefs;

  static Future<SharedPreferences> get prefs async {
    _prefs ??= await SharedPreferences.getInstance();
    return _prefs!;
  }

  static Future<String> getString(String key, String fallback) async {
    final p = await prefs;
    return p.getString(key) ?? fallback;
  }

  static Future<void> setString(String key, String value) async {
    final p = await prefs;
    await p.setString(key, value);
  }

  static Future<Map<String, dynamic>> getMap(String key) async {
    final raw = await getString(key, '{}');
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {}
    return <String, dynamic>{};
  }

  static Future<List<dynamic>> getList(String key) async {
    final raw = await getString(key, '[]');
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) return decoded;
    } catch (_) {}
    return <dynamic>[];
  }

  static Future<void> setJson(String key, Object value) async {
    await setString(key, jsonEncode(value));
  }

  static Future<void> clearAll() async {
    final p = await prefs;
    await p.clear();
  }
}

String todayKey() => DateTime.now().toIso8601String().substring(0, 10);
String monthKey() => DateTime.now().toIso8601String().substring(0, 7);
String uid() => DateTime.now().millisecondsSinceEpoch.toString();

class TareeqyNativeApp extends StatelessWidget {
  const TareeqyNativeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'طريقي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0EA5E9),
          brightness: Brightness.dark,
        ),
      ),
      home: const LockScreen(),
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final TextEditingController _pinController = TextEditingController();
  String _message = '';

  Future<void> _unlock() async {
    final savedPin = await Storage.getString('pin', AppConstants.defaultPin);
    if (_pinController.text == savedPin) {
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    } else {
      setState(() => _message = 'كلمة المرور غير صحيحة');
    }
  }

  Future<void> _resetData() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('مسح كل البيانات؟'),
        content: const Text('سيتم حذف كل البيانات المحلية وإرجاع كلمة المرور الافتراضية.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('مسح')),
        ],
      ),
    );
    if (ok == true) {
      await Storage.clearAll();
      await Storage.setString('pin', AppConstants.defaultPin);
      setState(() => _message = 'تم مسح البيانات. كلمة المرور: 135790');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Card(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('طريقي', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      const Text('أدخل كلمة المرور', textAlign: TextAlign.center),
                      const SizedBox(height: 18),
                      TextField(
                        controller: _pinController,
                        obscureText: true,
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 24),
                        decoration: const InputDecoration(border: OutlineInputBorder(), hintText: '135790'),
                        onSubmitted: (_) => _unlock(),
                      ),
                      const SizedBox(height: 12),
                      FilledButton.icon(onPressed: _unlock, icon: const Icon(Icons.lock_open), label: const Text('دخول')),
                      TextButton(onPressed: _resetData, child: const Text('مسح البيانات')),
                      if (_message.isNotEmpty) Text(_message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.amber)),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

enum AppTab { home, recovery, study, tasks, diary, backup, settings }

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  AppTab _tab = AppTab.home;
  int _refresh = 0;

  void refresh() => setState(() => _refresh++);

  @override
  Widget build(BuildContext context) {
    final pages = <AppTab, Widget>{
      AppTab.home: HomeScreen(key: ValueKey('home$_refresh'), goTo: (tab) => setState(() => _tab = tab)),
      AppTab.recovery: RecoveryScreen(key: ValueKey('recovery$_refresh'), onChanged: refresh),
      AppTab.study: StudyScreen(key: ValueKey('study$_refresh'), onChanged: refresh),
      AppTab.tasks: TasksScreen(key: ValueKey('tasks$_refresh'), onChanged: refresh),
      AppTab.diary: DiaryScreen(key: ValueKey('diary$_refresh'), onChanged: refresh),
      AppTab.backup: BackupScreen(key: ValueKey('backup$_refresh'), onChanged: refresh),
      AppTab.settings: SettingsScreen(key: ValueKey('settings$_refresh')),
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('طريقي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.lock),
            tooltip: 'قفل',
            onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LockScreen())),
          ),
        ],
      ),
      body: pages[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab.index,
        onDestinationSelected: (i) => setState(() => _tab = AppTab.values[i]),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.spa), label: 'التعافي'),
          NavigationDestination(icon: Icon(Icons.timer), label: 'المذاكرة'),
          NavigationDestination(icon: Icon(Icons.checklist), label: 'المهام'),
          NavigationDestination(icon: Icon(Icons.edit_note), label: 'اليوميات'),
          NavigationDestination(icon: Icon(Icons.backup), label: 'نسخ'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'إعدادات'),
        ],
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final void Function(AppTab tab) goTo;
  const HomeScreen({super.key, required this.goTo});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int recoveryDay = 1;
  int bestStreak = 0;
  int studyMinutes = 0;

  final messages = const [
    'ابدأ صغيرًا، لكن لا تتوقف.',
    'كل جلسة مذاكرة هي تصويت لصالح مستقبلك.',
    'الرجوع للطريق أهم من جلد الذات.',
    'اليوم الذي تسجله هو يوم يمكنك تحسينه.',
  ];
  late String message;

  @override
  void initState() {
    super.initState();
    message = messages[DateTime.now().second % messages.length];
    _load();
  }

  Future<void> _load() async {
    final rec = await Storage.getMap('recovery');
    final sessions = await Storage.getList('studySessions');
    final today = todayKey();
    final seconds = sessions.whereType<Map>().where((s) => s['date'] == today).fold<int>(0, (a, s) => a + ((s['seconds'] as num?)?.toInt() ?? 0));
    setState(() {
      recoveryDay = (rec['current'] as num?)?.toInt() ?? 1;
      bestStreak = (rec['best'] as num?)?.toInt() ?? 0;
      studyMinutes = (seconds / 60).round();
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('رسالة اليوم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(message, style: const TextStyle(fontSize: 22, height: 1.5)),
              const SizedBox(height: 12),
              FilledButton(onPressed: () => setState(() => message = messages[DateTime.now().millisecond % messages.length]), child: const Text('رسالة جديدة')),
            ],
          ),
        ),
        Row(
          children: [
            Expanded(child: StatCard(title: 'يوم التعافي', value: '$recoveryDay')),
            const SizedBox(width: 10),
            Expanded(child: StatCard(title: 'أفضل سلسلة', value: '$bestStreak')),
          ],
        ),
        StatCard(title: 'مذاكرة اليوم', value: '$studyMinutes د'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            QuickButton(label: 'التعافي', icon: Icons.spa, onTap: () => widget.goTo(AppTab.recovery)),
            QuickButton(label: 'المذاكرة', icon: Icons.timer, onTap: () => widget.goTo(AppTab.study)),
            QuickButton(label: 'المهام', icon: Icons.checklist, onTap: () => widget.goTo(AppTab.tasks)),
            QuickButton(label: 'اليوميات', icon: Icons.edit_note, onTap: () => widget.goTo(AppTab.diary)),
            QuickButton(label: 'نسخ احتياطي', icon: Icons.backup, onTap: () => widget.goTo(AppTab.backup)),
          ],
        ),
      ],
    );
  }
}

class RecoveryScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const RecoveryScreen({super.key, required this.onChanged});

  @override
  State<RecoveryScreen> createState() => _RecoveryScreenState();
}

class _RecoveryScreenState extends State<RecoveryScreen> {
  Map<String, dynamic> recovery = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    var rec = await Storage.getMap('recovery');
    if (rec.isEmpty) {
      rec = {
        'current': 1,
        'best': 0,
        'lastCheck': null,
        'log': [
          {'id': uid(), 'date': todayKey(), 'note': 'اليوم الأول في مرحلة التعافي'}
        ],
      };
      await Storage.setJson('recovery', rec);
    }
    setState(() => recovery = rec);
  }

  Future<void> _cleanDay() async {
    final today = todayKey();
    if (recovery['lastCheck'] == today) {
      _snack('تم تأكيد اليوم بالفعل');
      return;
    }
    final current = ((recovery['current'] as num?)?.toInt() ?? 0) + 1;
    final best = ((recovery['best'] as num?)?.toInt() ?? 0);
    final log = List<Map<String, dynamic>>.from(recovery['log'] as List? ?? []);
    log.insert(0, {'id': uid(), 'date': today, 'note': 'تأكيد يوم بدون انتكاسة - اليوم $current'});
    recovery = {'current': current, 'best': current > best ? current : best, 'lastCheck': today, 'log': log};
    await Storage.setJson('recovery', recovery);
    widget.onChanged();
    setState(() {});
  }

  Future<void> _relapse() async {
    final reason = await _askText('سبب أو محفز مختصر', 'اكتب السبب');
    final current = (recovery['current'] as num?)?.toInt() ?? 0;
    final best = (recovery['best'] as num?)?.toInt() ?? 0;
    final log = List<Map<String, dynamic>>.from(recovery['log'] as List? ?? []);
    log.insert(0, {'id': uid(), 'date': todayKey(), 'note': 'انتكاسة بعد $current يوم. ${reason ?? ''}'});
    recovery = {'current': 0, 'best': current > best ? current : best, 'lastCheck': null, 'log': log};
    await Storage.setJson('recovery', recovery);
    widget.onChanged();
    setState(() {});
  }

  Future<String?> _askText(String title, String hint) async {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, decoration: InputDecoration(hintText: hint)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text), child: const Text('حفظ')),
        ],
      ),
    );
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final current = (recovery['current'] as num?)?.toInt() ?? 1;
    final best = (recovery['best'] as num?)?.toInt() ?? 0;
    final last = recovery['lastCheck']?.toString() ?? 'لم يتم';
    final log = List<Map>.from(recovery['log'] as List? ?? []);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [Expanded(child: StatCard(title: 'اليوم الحالي', value: '$current')), const SizedBox(width: 10), Expanded(child: StatCard(title: 'أفضل مدة', value: '$best'))]),
        StatCard(title: 'آخر تأكيد', value: last),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            FilledButton(onPressed: _cleanDay, child: const Text('تأكيد يوم بدون انتكاسة')),
            const SizedBox(height: 10),
            FilledButton.tonal(onPressed: _relapse, child: const Text('حدثت انتكاسة / ابدأ من الصفر')),
          ]),
        ),
        const Text('سجل التعافي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...log.map((e) => AppCard(child: ListTile(title: Text(e['date'].toString()), subtitle: Text(e['note'].toString())))),
      ],
    );
  }
}

class StudyScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const StudyScreen({super.key, required this.onChanged});

  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> {
  final topicController = TextEditingController();
  final notesController = TextEditingController();
  int timerSeconds = 25 * 60;
  int selectedMinutes = 25;
  Timer? timer;
  bool timerRunning = false;

  int stopwatchSeconds = 0;
  Timer? stopwatch;
  bool stopwatchRunning = false;
  List<Map<String, dynamic>> sessions = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    timer?.cancel();
    stopwatch?.cancel();
    topicController.dispose();
    notesController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final list = await Storage.getList('studySessions');
    setState(() => sessions = list.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList());
  }

  Future<void> _saveSession({required String mode, required int seconds}) async {
    if (seconds < 30) {
      _snack('الجلسة أقل من 30 ثانية');
      return;
    }
    final session = {
      'id': uid(),
      'date': todayKey(),
      'time': TimeOfDay.now().format(context),
      'mode': mode,
      'kind': 'studied',
      'topic': topicController.text.trim().isEmpty ? 'بدون موضوع' : topicController.text.trim(),
      'notes': notesController.text.trim(),
      'seconds': seconds,
    };
    sessions.insert(0, session);
    await Storage.setJson('studySessions', sessions);
    widget.onChanged();
    setState(() {});
    _snack('تم حفظ الجلسة');
  }

  void _startTimer() {
    if (timerRunning) return;
    setState(() => timerRunning = true);
    timer = Timer.periodic(const Duration(seconds: 1), (t) async {
      if (timerSeconds <= 1) {
        t.cancel();
        final total = selectedMinutes * 60;
        setState(() {
          timerSeconds = total;
          timerRunning = false;
        });
        await _saveSession(mode: 'timer', seconds: total);
      } else {
        setState(() => timerSeconds--);
      }
    });
  }

  void _pauseTimer() {
    timer?.cancel();
    setState(() => timerRunning = false);
  }

  void _resetTimer() {
    timer?.cancel();
    setState(() {
      timerRunning = false;
      timerSeconds = selectedMinutes * 60;
    });
  }

  void _startStopwatch() {
    if (stopwatchRunning) return;
    setState(() => stopwatchRunning = true);
    stopwatch = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => stopwatchSeconds++));
  }

  void _pauseStopwatch() {
    stopwatch?.cancel();
    setState(() => stopwatchRunning = false);
  }

  Future<void> _saveStopwatch() async {
    _pauseStopwatch();
    await _saveSession(mode: 'stopwatch', seconds: stopwatchSeconds);
    setState(() => stopwatchSeconds = 0);
  }

  void _resetStopwatch() {
    stopwatch?.cancel();
    setState(() {
      stopwatchRunning = false;
      stopwatchSeconds = 0;
    });
  }

  String _fmt(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  int _todaySeconds() => sessions.where((s) => s['date'] == todayKey()).fold<int>(0, (a, s) => a + ((s['seconds'] as num?)?.toInt() ?? 0));
  int _monthSeconds() => sessions.where((s) => (s['date'] ?? '').toString().startsWith(monthKey())).fold<int>(0, (a, s) => a + ((s['seconds'] as num?)?.toInt() ?? 0));

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(children: [Expanded(child: StatCard(title: 'اليوم', value: '${(_todaySeconds() / 60).round()} د')), const SizedBox(width: 10), Expanded(child: StatCard(title: 'الشهر', value: '${(_monthSeconds() / 3600).toStringAsFixed(1)} س'))]),
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('بيانات الجلسة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            TextField(controller: topicController, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'الموضوع')),
            const SizedBox(height: 10),
            TextField(controller: notesController, maxLines: 2, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'ملاحظات')),
          ]),
        ),
        AppCard(
          child: Column(children: [
            const Text('Timer', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            DropdownButton<int>(
              value: selectedMinutes,
              items: const [15, 25, 30, 45, 60].map((m) => DropdownMenuItem(value: m, child: Text('$m دقيقة'))).toList(),
              onChanged: (v) => setState(() {
                selectedMinutes = v ?? 25;
                timerSeconds = selectedMinutes * 60;
              }),
            ),
            Text(_fmt(timerSeconds), style: const TextStyle(fontSize: 52, fontWeight: FontWeight.bold)),
            Wrap(spacing: 10, children: [FilledButton(onPressed: _startTimer, child: const Text('ابدأ')), OutlinedButton(onPressed: _pauseTimer, child: const Text('إيقاف')), OutlinedButton(onPressed: _resetTimer, child: const Text('تصفير'))]),
          ]),
        ),
        AppCard(
          child: Column(children: [
            const Text('Stopwatch', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(_fmt(stopwatchSeconds), style: const TextStyle(fontSize: 52, fontWeight: FontWeight.bold)),
            Wrap(spacing: 10, children: [FilledButton(onPressed: _startStopwatch, child: const Text('ابدأ')), OutlinedButton(onPressed: _pauseStopwatch, child: const Text('إيقاف')), FilledButton.tonal(onPressed: _saveStopwatch, child: const Text('حفظ')), OutlinedButton(onPressed: _resetStopwatch, child: const Text('تصفير'))]),
          ]),
        ),
        const Text('الجلسات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ...sessions.take(40).map((s) => AppCard(child: ListTile(title: Text('${s['topic']} — ${_fmt((s['seconds'] as num?)?.toInt() ?? 0)}'), subtitle: Text('${s['date']} ${s['time']}\n${s['notes'] ?? ''}')))),
      ],
    );
  }
}

class TasksScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const TasksScreen({super.key, required this.onChanged});

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final customController = TextEditingController();
  final defaults = const ['تأكيد يوم بدون انتكاسة', 'جلسة مذاكرة', 'مراجعة', 'لا موبايل في السرير', 'كتابة يومية', 'معلومة جديدة', 'مشي/رياضة', 'نوم بدري'];
  List<Map<String, dynamic>> tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await Storage.getMap('dailyTasks');
    final today = todayKey();
    if (all[today] == null) {
      all[today] = defaults.map((t) => {'id': uid(), 'text': t, 'done': false}).toList();
      await Storage.setJson('dailyTasks', all);
    }
    setState(() => tasks = List<Map<String, dynamic>>.from((all[today] as List).map((e) => Map<String, dynamic>.from(e))));
  }

  Future<void> _save() async {
    final all = await Storage.getMap('dailyTasks');
    all[todayKey()] = tasks;
    await Storage.setJson('dailyTasks', all);
    widget.onChanged();
  }

  Future<void> _addTask() async {
    final text = customController.text.trim();
    if (text.isEmpty) return;
    tasks.add({'id': uid(), 'text': text, 'done': false});
    customController.clear();
    await _save();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t['done'] == true).length;
    final percent = tasks.isEmpty ? 0 : (done / tasks.length * 100).round();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        StatCard(title: 'إنجاز اليوم', value: '$percent%'),
        AppCard(
          child: Column(
            children: tasks.map((t) => CheckboxListTile(
              value: t['done'] == true,
              title: Text(t['text'].toString()),
              onChanged: (v) async {
                t['done'] = v ?? false;
                await _save();
                setState(() {});
              },
            )).toList(),
          ),
        ),
        AppCard(child: Row(children: [Expanded(child: TextField(controller: customController, decoration: const InputDecoration(labelText: 'مهمة جديدة'))), IconButton(onPressed: _addTask, icon: const Icon(Icons.add_circle))])),
      ],
    );
  }
}

class DiaryScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const DiaryScreen({super.key, required this.onChanged});

  @override
  State<DiaryScreen> createState() => _DiaryScreenState();
}

class _DiaryScreenState extends State<DiaryScreen> {
  final titleController = TextEditingController();
  final textController = TextEditingController();
  List<Map<String, dynamic>> diaries = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await Storage.getList('diaries');
    setState(() => diaries = list.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList());
  }

  Future<void> _saveDiary() async {
    final text = textController.text.trim();
    if (text.isEmpty) return;
    diaries.insert(0, {'id': uid(), 'date': todayKey(), 'title': titleController.text.trim().isEmpty ? 'بدون عنوان' : titleController.text.trim(), 'text': text});
    await Storage.setJson('diaries', diaries);
    titleController.clear();
    textController.clear();
    widget.onChanged();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            TextField(controller: titleController, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'العنوان')),
            const SizedBox(height: 10),
            TextField(controller: textController, minLines: 4, maxLines: 8, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'اليومية')),
            const SizedBox(height: 10),
            FilledButton(onPressed: _saveDiary, child: const Text('حفظ اليومية')),
          ]),
        ),
        ...diaries.map((d) => AppCard(child: ListTile(title: Text(d['title'].toString()), subtitle: Text('${d['date']}\n${d['text']}')))),
      ],
    );
  }
}

class BackupScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const BackupScreen({super.key, required this.onChanged});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  Future<Map<String, dynamic>> _collectData() async {
    return {
      'recovery': await Storage.getMap('recovery'),
      'studySessions': await Storage.getList('studySessions'),
      'dailyTasks': await Storage.getMap('dailyTasks'),
      'diaries': await Storage.getList('diaries'),
      'pin': await Storage.getString('pin', AppConstants.defaultPin),
    };
  }

  Future<void> _exportBackup() async {
    final backup = {
      'appName': AppConstants.appName,
      'appVersion': AppConstants.appVersion,
      'backupVersion': AppConstants.backupVersion,
      'createdAt': DateTime.now().toIso8601String(),
      'data': await _collectData(),
    };
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/tareeqy-native-backup-${todayKey()}.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(backup));
    await Share.shareXFiles([XFile(file.path)], text: 'Tareeqy Native Backup');
  }

  Future<void> _importBackup() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json']);
    if (result == null || result.files.single.path == null) return;
    try {
      final raw = await File(result.files.single.path!).readAsString();
      final decoded = jsonDecode(raw);
      final data = decoded is Map && decoded['data'] is Map ? Map<String, dynamic>.from(decoded['data']) : Map<String, dynamic>.from(decoded as Map);
      await Storage.setJson('recovery', data['recovery'] ?? {});
      await Storage.setJson('studySessions', data['studySessions'] ?? []);
      await Storage.setJson('dailyTasks', data['dailyTasks'] ?? {});
      await Storage.setJson('diaries', data['diaries'] ?? []);
      if (data['pin'] != null) await Storage.setString('pin', data['pin'].toString());
      widget.onChanged();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الاستيراد بنجاح')));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ملف غير صالح')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('النسخ الاحتياطي', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('يتم تصدير ملف JSON واستيراده. النسخة الحالية تدعم PIN، التعافي، المذاكرة، المهام، واليوميات.'),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: _exportBackup, icon: const Icon(Icons.upload_file), label: const Text('تصدير نسخة')),
            const SizedBox(height: 10),
            FilledButton.tonalIcon(onPressed: _importBackup, icon: const Icon(Icons.download), label: const Text('استيراد نسخة')),
          ]),
        ),
      ],
    );
  }
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final pinController = TextEditingController(text: AppConstants.defaultPin);

  Future<void> _savePin() async {
    final pin = pinController.text.trim().isEmpty ? AppConstants.defaultPin : pinController.text.trim();
    await Storage.setString('pin', pin);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ كلمة المرور')));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('الإعدادات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(controller: pinController, keyboardType: TextInputType.number, decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'كلمة المرور')),
            const SizedBox(height: 10),
            FilledButton(onPressed: _savePin, child: const Text('حفظ كلمة المرور')),
            const SizedBox(height: 14),
            const Text('App Version: ${AppConstants.appVersion}\nBackup Version: ${AppConstants.backupVersion}'),
          ]),
        ),
      ],
    );
  }
}

class AppCard extends StatelessWidget {
  final Widget child;
  const AppCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(padding: const EdgeInsets.all(16), child: child),
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  const StatCard({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 6),
        Text(value, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
      ]),
    );
  }
}

class QuickButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const QuickButton({super.key, required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 150,
      child: FilledButton.tonalIcon(onPressed: onTap, icon: Icon(icon), label: Text(label)),
    );
  }
}
