# طريقي Flutter Native MVP

دي أول نسخة Native Flutter حقيقية، وليست WebView.

## الموجود في النسخة

- PIN Lock بكلمة مرور افتراضية: `135790`
- الرئيسية
- التعافي
- مذاكرة Timer
- Stopwatch
- مهام يومية
- يوميات
- Backup/Restore JSON
- إعدادات تغيير كلمة المرور
- GitHub Actions لبناء APK من الموبايل أو الكمبيوتر

## البناء على GitHub من الموبايل

1. اعمل Repository جديد على GitHub.
2. ارفع محتويات هذا المشروع، وليس ملف ZIP نفسه.
3. تأكد من وجود الملفات:

```text
.github/workflows/build-apk.yml
lib/main.dart
pubspec.yaml
README.md
```

4. افتح تبويب Actions.
5. شغل Workflow باسم:

```text
Build Native Flutter APK
```

6. بعد انتهاء البناء، حمّل Artifact:

```text
tareeqy-native-release-apk
```

7. فك الضغط وثبت:

```text
app-release.apk
```

## ملاحظات

- التطبيق Native Flutter، لا يحتاج Netlify.
- البيانات محفوظة على الجهاز باستخدام SharedPreferences بصيغة JSON.
- النسخ الاحتياطي يصدر ملف JSON يمكن مشاركته وحفظه على Google Drive.
- هذه نسخة MVP، وبعدها يمكن إضافة: المكتبة، المفضلات، الإحصائيات المتقدمة، المحفزات، وضع التركيز، وصفحة الامتياز.
